# Aura Brand Kit Image Prompt

## Промпт, использованный для генерации Brand Kit

```text
A comprehensive brand-kit presentation board for a natural face yoga and rejuvenation blog. The board is divided into sections: 1. Color Palette (linen #f2f0eb, white #ffffff, blush #f5dfe3, blush-deep #d4b8b8, rose-silk #e8b4bc, gold-mid #c9a227). 2. Typography (elegant serif headings, clean sans-serif body). 3. UI Components (soft rounded buttons, elegant thin borders). 4. Photography style (natural, glowing skin, yoga, soft light). 5. Layout preview (clean, airy, feminine, minimalist). High quality, elegant, professional layout, Dribbble style presentation, soft pastel pinks and golds.
```

## Инструмент
`user-mcp-kv/gpt-image-2` (Text to Image)

## Результат
[Brand Kit Image](https://tempfile.aiquickdraw.com/images/chatgpt/7518a41735c92159485c1158c9750867_a780832a6ce14f99ac51271fb7dc9404.png)
