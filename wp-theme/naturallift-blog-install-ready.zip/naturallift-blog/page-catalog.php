<?php
/**
 * Template Name: Cosmetics Catalog
 */

get_header(); ?>

<div class="container" style="padding-top: var(--space-lg); padding-bottom: var(--space-xl);">
    <header class="catalog-page-header" style="text-align: center; margin-bottom: var(--space-xl);">
        <span class="product-promo__kicker">Premium Cosmeceuticals</span>
        <h1 style="font-size: 56px; margin-bottom: 16px; font-family: var(--font-heading); line-height: 1.1; color: var(--color-text);">Моя косметика</h1>
        <p class="catalog-subtitle" style="font-family: var(--font-script); font-size: 32px; color: var(--color-text-muted); max-width: 600px; margin: 0 auto;">Авторская линия натуральной косметики Silver Cream</p>
        <div class="divider" style="margin-top: 24px;"></div>
    </header>

    <div class="catalog-grid">
        <!-- Продукт 1 -->
        <article class="catalog-item">
            <div class="catalog-item__image">
                <img src="https://naturallift.ru/wp-content/uploads/2026/02/dnevnoj-uvlazhnyayushhij-krem-9-na-16-scaled.jpg" alt="Дневной увлажняющий крем Silver Cream">
            </div>
            <div class="catalog-item__info">
                <span class="catalog-item__label">Дневной уход · Bestseller</span>
                <h2>Дневной увлажняющий крем</h2>
                <p class="catalog-item__desc">Лёгкая невесомая текстура, разработанная специально для защиты и глубокого увлажнения кожи в течение всего дня. Быстро впитывается, служит превосходной базой под макияж и дарит коже естественное, здоровое сияние без жирного блеска.</p>
                
                <div class="catalog-item__ingredients">
                    <strong>Активные компоненты:</strong>
                    <ul>
                        <li>Экстракт эдельвейса — мощный природный антиоксидант</li>
                        <li>Низкомолекулярная гиалуроновая кислота — глубокое увлажнение</li>
                        <li>Натуральные масла арганы и жожоба — питание и мягкость</li>
                        <li>Д-пантенол — восстановление защитного барьера</li>
                    </ul>
                </div>
                
                <div class="catalog-item__action">
                    <span class="catalog-item__price">3 200 ₽</span>
                    <a href="https://t.me/silver_cream" class="btn btn-primary" target="_blank">Заказать в Telegram</a>
                </div>
            </div>
        </article>

        <!-- Продукт 2 -->
        <article class="catalog-item catalog-item--reverse">
            <div class="catalog-item__image">
                <img src="https://naturallift.ru/wp-content/uploads/2026/03/42c7a1779ed2d0c9f50fa3dc165d202e_d64b7ab3-e344-40a0-85e0-3e9227435d85.png" alt="Ночной восстанавливающий крем Silver Cream">
            </div>
            <div class="catalog-item__info">
                <span class="catalog-item__label">Ночной ритуал · Регенерация</span>
                <h2>Ночной восстанавливающий крем</h2>
                <p class="catalog-item__desc">Более плотная, питательная текстура, которая запускает процессы ночного восстановления клеток. Крем эффективно борется с утренней отечностью, укрепляет липидный барьер и глубоко питает кожу, пока вы отдыхаете. Утром лицо выглядит свежим и гладким.</p>
                
                <div class="catalog-item__ingredients">
                    <strong>Активные компоненты:</strong>
                    <ul>
                        <li>Пептидный комплекс — стимуляция выработки коллагена</li>
                        <li>Натуральный сквалан — удержание влаги и эластичность</li>
                        <li>Масло ши (карите) — глубокое питание кожи</li>
                        <li>Экстракт зеленого чая — лимфодренаж и борьба с отеками</li>
                    </ul>
                </div>
                
                <div class="catalog-item__action">
                    <span class="catalog-item__price">3 500 ₽</span>
                    <a href="https://t.me/silver_cream" class="btn btn-primary" target="_blank">Заказать в Telegram</a>
                </div>
            </div>
        </article>

        <!-- Продукт 3 -->
        <article class="catalog-item">
            <div class="catalog-item__image">
                <img src="https://naturallift.store/wp-content/uploads/2026/05/сыворотка-для-лица-с-пептидами.jpg" alt="Омолаживающая сыворотка Silver Cream">
            </div>
            <div class="catalog-item__info">
                <span class="catalog-item__label">Интенсивный уход · Лифтинг</span>
                <h2>Сыворотка для лица с пептидами</h2>
                <p class="catalog-item__desc">Высококонцентрированная сыворотка-активатор для интенсивного омоложения. Уникальный пептидный комплекс расслабляет мимическое напряжение (эффект мягкого ботокса), разглаживает морщины и моделирует красивый, четкий овал лица. Идеально сочетается с практиками фейс-йоги.</p>
                
                <div class="catalog-item__ingredients">
                    <strong>Активные компоненты:</strong>
                    <ul>
                        <li>Пептиды-миорелаксанты — разглаживание мимических морщин</li>
                        <li>Витамин С (стабильная форма) — выравнивание тона и сияние</li>
                        <li>Ниацинамид (витамин В3) — сужение пор и улучшение текстуры</li>
                        <li>Провитамин В5 — успокаивающий и заживляющий эффект</li>
                    </ul>
                </div>
                
                <div class="catalog-item__action">
                    <span class="catalog-item__price">3 800 ₽</span>
                    <a href="https://t.me/silver_cream" class="btn btn-primary" target="_blank">Заказать в Telegram</a>
                </div>
            </div>
        </article>
    </div>

    <!-- Философия ухода -->
    <section class="catalog-philosophy" style="margin-top: 100px; padding: 60px; background: var(--color-surface); border: 1px solid var(--color-border); text-align: center;">
        <span class="product-promo__kicker">Философия Silver Cream</span>
        <h2 style="font-size: 36px; font-family: var(--font-heading); margin-bottom: 24px; color: var(--color-text);">Синергия косметики и фейс-йоги</h2>
        <p style="max-width: 800px; margin: 0 auto 32px; color: var(--color-text-muted); font-size: 16px; line-height: 1.8;">
            Я создаю косметику Silver Cream по принципу полной синергии с мануальными практиками. Натуральные формулы из профессиональных ингредиентов подготавливают кожу к массажу, улучшают скольжение и мгновенно усваиваются при разогреве тканей во время фейс-йоги. Это позволяет добиться двойного лифтинг-эффекта и закрепить результат надолго.
        </p>
        <div style="font-family: var(--font-script); font-size: 28px; color: var(--color-primary);">С любовью к вашей коже, Елена Шимановская</div>
    </section>
</div>

<?php get_footer(); ?>
